import { Injectable } from '@angular/core';
import { Http, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Vehicle } from '../vehicles/vehicle';
import { VehicleSpec } from '../vehicles/vehicle-spec';

@Injectable()
export class VehicleService {

  constructor(public httpSvc: Http) { }

  getVehicleList(): Observable<Vehicle[]> {
    return this.httpSvc.get("./app/api/vehicle.json")
      .map((response) => <Vehicle[]>response.json())
      .catch((error) => Observable.throw(error))
  }

  getVehicleSpecification(): Observable<VehicleSpec[]> {
    return this.httpSvc.get("./app/api/vehicle-specification.json")
      .map((response) => <VehicleSpec[]>response.json())
      .catch((error) => Observable.throw(error))
  }

}



