export class Vehicle {
    public year: number;
    public make: string;
    public model: string;
}