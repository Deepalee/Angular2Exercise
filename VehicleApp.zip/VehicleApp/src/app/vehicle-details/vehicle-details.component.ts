import { Component, OnInit, Input } from '@angular/core';
import { Vehicle } from '../vehicles/vehicle';
import { VehicleSpec } from '../vehicles/vehicle-spec';
import { VehicleService } from '../services/vehicle.service';
import { Observable } from 'rxjs/Observable';
import { VehicleListComponent } from '../vehicle-list/vehicle-list.component';

@Component({
  selector: 'app-vehicle-details',
  templateUrl: './vehicle-details.component.html',
  styleUrls: ['./vehicle-details.component.css']
})

export class VehicleDetailsComponent implements OnInit {
  @Input() selvehicle: Vehicle[] = [];
  @Input() vehicleSelected: boolean;
  vDetails: VehicleSpec[] = [];
  selectedVehicleSpec: VehicleSpec[] = [];

  year: number;
  make: string;
  model: string;

  constructor(private vehicleSrv: VehicleService) {

    this.vehicleSrv.getVehicleSpecification()
      .subscribe(
      (result) => {
        this.vDetails = result;
        this.getSelectedVehicleSpecification(this.year, this.make, this.model);
        console.log("constructor: " + result);
      },
      (error) => {
        console.log("Error retrieving Vehicle Scpecification!");
        return Observable.throw(error);
      }
      );

    console.log("selvehicle : " + this.selvehicle);
  }


  getSelectedVehicleSpecification(year: number, make: string, model: string) {
    let recFound:boolean = false;
    for (var i = 0; i < this.vDetails.length; i++) {
      //console.log(this.year + ":" + this.vDetails[i].year);
      //console.log(this.make + ":" + this.vDetails[i].make);
      //console.log(this.model + ":" + this.vDetails[i].model);
      if (this.vDetails[i].year === this.year && this.vDetails[i].make === this.make && this.vDetails[i].model === this.model) {
        this.selectedVehicleSpec[0] = this.vDetails[i];
        recFound = true;
        break;
        //   console.log("Selected Vehicle Spec: " + this.selectedVehicleSpec[0]);
      }
      if (!recFound){
        this.selectedVehicleSpec[0] = this.vDetails[0];
      }

    }
  }



ngOnChanges(changes) {
  console.log('Changed', changes.selvehicle.currentValue, changes.selvehicle.previousValue);
  this.year = changes.selvehicle.currentValue.year;
  this.make = changes.selvehicle.currentValue.make;
  this.model = changes.selvehicle.currentValue.model;
  console.log("ngOnChanges :" + this.year + ":" + this.make + ":" + this.model);
  this.getSelectedVehicleSpecification(this.year, this.make, this.model);
}

ngOnInit() {
  console.log('Init', this.selvehicle);
}

}
