import { Component, OnInit } from '@angular/core';
import { VehicleService } from '../services/vehicle.service';
import { Vehicle } from '../vehicles/vehicle';
import { Observable } from 'rxjs/Observable';
import { PagerService } from '../services/pager.service';
import { OrderBy } from "../vehicles/orderBy";


@Component({
  selector: 'app-vehicle-list',
  templateUrl: './vehicle-list.component.html',
  styleUrls: ['./vehicle-list.component.css']
})
export class VehicleListComponent implements OnInit {
  vehicle: Vehicle;
  vehicleSelected: boolean;
  vehicles: Vehicle[] = [];
  dearlerName: string;
  // pager object
  pager: any = {};
  count: number = 0;

  // paged items
  pagedItems: Vehicle[] = [];

  columns: any[] = [
    {
      display: 'Year', //The text to display
      variable: 'year', //The name of the key that's apart of the data array
      filter: 'number' //The type data type of the column (number, text, date, etc.)
    },
    {
      display: 'Make', //The text to display
      variable: 'make', //The name of the key that's apart of the data array
      filter: 'text' //The type data type of the column (number, text, date, etc.)
    },
    {
      display: 'Model', //The text to display
      variable: 'model', //The name of the key that's apart of the data array
      filter: 'text' //The type data type of the column (number, text, date, etc.)
    }
  ];

  sort: any = {
    column: 'year', //to match the variable of one of the columns
    descending: false
  };

  constructor(private vehicleSrv: VehicleService, private pagerSrv: PagerService) {
    this.dearlerName = "Royal Motors";
    this.getVehicleList();
  }

  ngOnInit() {
  }


  private getVehicleList() {
    this.vehicleSrv.getVehicleList().subscribe(
      (result) => {
        this.vehicles = result;
        // initialize to page 1
        this.setPage(1);

      },
      error => {
        console.log("Error retrieving Vehicles!");
        return Observable.throw(error);
      }
    );
    console.log(this.vehicles);

  }

  setPage(page: number) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }

    // get pager object from service
    this.pager = this.pagerSrv.getPager(this.vehicles.length, page);

    // get current page of items
    //  this.pagedItems = this.vehicles.slice(this.pager.startIndex, this.pager.endIndex + 1);
    this.vehicleSelected = false;
  }

  viewVehicleDetails(selectedVehicle: Vehicle) {
    this.vehicle = selectedVehicle;
    this.vehicleSelected = true;
  }


  selectedClass(columnName): any {
    return columnName == this.sort.column ? 'sort-' + this.sort.descending : false;
  }

  changeSorting(columnName): void {
    var sort = this.sort;
    if (sort.column == columnName) {
      sort.descending = !sort.descending;
    } else {
      sort.column = columnName;
      sort.descending = false;
    }
  }

  convertSorting(): string {
    return this.sort.descending ? '-' + this.sort.column : this.sort.column;
  }

}
